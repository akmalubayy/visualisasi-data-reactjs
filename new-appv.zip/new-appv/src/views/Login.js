import React from "react";
import PropTypes from "prop-types";
import { Container, Row, Col } from "shards-react";

const Login = () => {
    return(
        <div>
        lalalaa
        </div>
    )
}

export default Login;